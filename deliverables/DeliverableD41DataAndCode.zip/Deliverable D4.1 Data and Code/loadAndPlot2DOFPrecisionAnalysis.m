
clear all
close all
load("angSensitivity.mat");
load("infineon.mat");
load("TexasInstruments.mat");

correction=0.15;
all_marks = {'+','o','*','v','x','s','d','^','v','>','<','p','h'};
linestyles= {'-','-','--','--','-.','-.'};
figure
for i=2:size(angSensitivity,2)


    leg(i-1)=cellstr([num2str(angSensitivity(1,i)) '^{o}']);

    xx = 1.5:.25:7.5;
    if i==6
        xx=1.5:0.25:5.5;
    end
    yy=spline(angSensitivity(2:end,1),angSensitivity(2:end,i),xx);
plot(xx,yy,'LineStyle',linestyles{i-1},'Marker',all_marks{mod(i,13)},'Color','black');
hold on
end
legend(leg)
grid on
xlabel('Distance (m)','FontWeight','bold');
ylabel('Azimuth Error (degrees^{o})','FontWeight','bold');


savefig('AzimuthSensitivityTexas.fig');
saveas(gcf,'AzimuthSensitivityTexas.png','png');


figure
hold on
count=1;
for i=2:size(Infineon,2)


    leg(count)=cellstr(['Infineon ' num2str(Infineon(1,i)) '^{o}']);
    count=count+1;
    leg(count)=cellstr(['TI ' num2str(TexasInstruments(1,i)) '^{o}']);
    count=count+1;
    xx = 1.5:.25:7;
    if i==6
        xx=1.5:0.25:5.5;
    end
    yy=spline(Infineon(2:end,1),Infineon(2:end,i)-Infineon(2:end,1)-correction,xx);
    yy2=spline(TexasInstruments(2:end,1),TexasInstruments(2:end,i)-TexasInstruments(2:end,1)-correction,xx);
plot(xx,yy,'LineStyle',linestyles{i-1},'Marker',all_marks{mod(i,13)},'Color','black');

plot(xx,yy2,'LineStyle',linestyles{i+1},'Marker',all_marks{mod(i+2,13)},'Color','black');
end
legend(leg)
grid on
xlabel('Distance (m)','FontWeight','bold');
ylabel('Distance Error (m)','FontWeight','bold');
savefig('TexasVsInfeneonDistanceAccuracy.fig');
saveas(gcf,'TexasVsInfeneonDistanceAccuracy.png','png');

figure
hold on
count=1;
for i=2:size(TexasInstruments,2)



    leg(count)=cellstr(['TI ' num2str(TexasInstruments(1,i)) '^{o}']);
    count=count+1;
    xx = 1.5:.25:7;
    if i==6
        xx=1.5:0.25:5.5;
    end
    yy2=spline(TexasInstruments(2:end,1),TexasInstruments(2:end,i)-TexasInstruments(2:end,1)-correction,xx);


plot(xx,yy2,'LineStyle',linestyles{i-1},'Marker',all_marks{mod(i,13)},'Color','black');
end
legend(leg)
grid on
xlabel('Distance (m)','FontWeight','bold');
ylabel('Distance Error (m)','FontWeight','bold');
savefig('TexasDistanceSensitivity.fig');
saveas(gcf,'TexasDistanceSensitivity.png','png');
