% This is a function to load and plot the results of the 2DOF precision Analysis
clear all
load("precisionIWR1843XYZ.mat")




[dd(:,:,1),elev(:,:,1),azim(:,:,1),err3d(:,:,1),rangeErr(:,:,1),azErr(:,:,1),elErr(:,:,1)]=plotPrecisionAccuracy(AZ00xyz,0);
[dd(:,:,end+1),elev(:,:,end+1),azim(:,:,end+1),err3d(:,:,end+1),rangeErr(:,:,end+1),azErr(:,:,end+1),elErr(:,:,end+1)]=plotPrecisionAccuracy(AZ15xyz,15);
[dd(:,:,end+1),elev(:,:,end+1),azim(:,:,end+1),err3d(:,:,end+1),rangeErr(:,:,end+1),azErr(:,:,end+1),elErr(:,:,end+1)]=plotPrecisionAccuracy(AZ30xyz,30);
[dd(:,:,end+1),elev(:,:,end+1),azim(:,:,end+1),err3d(:,:,end+1),rangeErr(:,:,end+1),azErr(:,:,end+1),elErr(:,:,end+1)]=plotPrecisionAccuracy(AZ45xyz,45);
[dd(:,:,end+1),elev(:,:,end+1),azim(:,:,end+1),err3d(:,:,end+1),rangeErr(:,:,end+1),azErr(:,:,end+1),elErr(:,:,end+1)]=plotPrecisionAccuracy(AZ60xyz,60);


function [dnew,elnew,aznew,error3dnew,rangeErrornew,azimuthErrornew,elevationErrornew]=plotPrecisionAccuracy(data,azimuth)
    azimuthString=num2str(azimuth);
    filename=['precisionXYZ_azz' azimuthString];

    [d,el]=meshgrid(0.5:1:6.5,0:15:45);
    error3d=zeros(size(d));
    rangeError=zeros(size(d));
    azimuthError=zeros(size(d));
    elevationError=zeros(size(d));
    for i=1:size(d,1)
        for j=1:size(d,2)
            ind=intersect(find(data(:,1)==d(i,j)),find(data(:,3)==el(i,j)));
            if isempty(ind)
                error3d(i,j)=NaN;
                rangeError(i,j)=NaN;
                azimuthError(i,j)=NaN;
                elevationError(i,j)=NaN;
            else
                error3d(i,j)=data(ind,19);
                rangeError(i,j)=data(ind,7);
                azimuthError(i,j)=data(ind,8);
                elevationError(i,j)=data(ind,9);
            end
        
        end
    end
    
    
    [dnew,elnew]=meshgrid(0.5:.1:6.5,0:1:45);
    aznew=ones(size(elnew))*azimuth;
    rangeErrornew = interp2(d,el,rangeError,dnew,elnew);
    azimuthErrornew = interp2(d,el,azimuthError,dnew,elnew);
    elevationErrornew = interp2(d,el,elevationError,dnew,elnew);
    error3dnew = interp2(d,el,error3d,dnew,elnew);
    fig=figure;
    surf(dnew, elnew, error3dnew,'FaceAlpha',0.5);
    xlabel("Distance (m)",FontWeight="bold");
    ylabel(['Elevation (Degrees' char(176) ')' ],FontWeight="bold",FontSmoothing="on");
    zlabel("3D Error (m)",FontWeight="bold");
    % title(['Azimuth=' azimuthString ' degrees' char(176)])
    % colormap("gray")
    
    zlim([0 1.5]);
    xlim([0 6.5]);
    ylim([0 45]);
    view(-23,23);
    grid minor;
    threshold=0.4;
    lessThanThresholdIndexes=find(error3dnew>threshold);
    error3DbelowThreshoold=error3dnew;
    error3DbelowThreshoold(lessThanThresholdIndexes)=NaN;
    hold on
    % scatter3(dnew(lessThanThresholdIndexes),elnew(lessThanThresholdIndexes),zeros(size(dnew(lessThanThresholdIndexes))),'o','filled','MarkerFaceAlpha',0.2,'MarkerFaceColor','k')
    contourf(dnew,elnew,error3DbelowThreshoold);
    saveas(fig,filename,'epsc')
end