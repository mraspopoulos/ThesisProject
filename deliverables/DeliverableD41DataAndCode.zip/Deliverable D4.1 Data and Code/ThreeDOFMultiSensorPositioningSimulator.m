% Download and place in the same folder the following funation
%interparc.m
% https://www.mathworks.com/matlabcentral/fileexchange/34874-interparc

clear all
close all
numberOfElecmentsToInterpolate=100;
maxNumberofScatteredPoints=50;
sigma=0.2;

load('precisionIWR1843_3DMatrices_interpolated.mat');

%Define the Route
x=[1.2 2.7 4.2 4.8 4.1 5.0 3.0 1.3 1.1 0.9 1.8 2.7 3.1];
y=[1.0, 1.2 0.7 3.0 5.8 6.8 7.1 7.3 7.0 4.2 5.0 5.2 3.0];
z=[2.2 2.0 1.7 3.0 2.7 3.0 3.2 2.4 2.2 1.7 1.5 1.2 0.4];

%Define the room specifications
height=3.5;
roomWidth=6.58;
roomLength=8.866;
workingSpaceStartingX=4.551;
workingSpaceLength=7.692;
workingSpaceLenghtExtra=0.62;
workingSpaceHeight=2.2;
benchStartingX=2;
benchStartingY=3.46;
benchWidth=0.9;
benchLength=4.2;
benchHeight=0.9;
doorStartingX=0.97;
doorWidth=1.07;
doorHeight=2.16;
shelfStartingY=0.74;
shelfWidth=0.63;
shelfLenght=2.53;
shelfHeight=1.79;
numberOfSelves=3;

%Create the environment
building.facet(1)=createVerFacet([0 roomWidth],[0 0],0,height,'external_wall'); 
building.facet(end+1)=createVerFacet([roomWidth roomWidth],[0 roomLength],0,height,'external_wall'); 
building.facet(end+1)=createVerFacet([roomWidth 0],[roomLength roomLength],0,height,'external_wall'); 
building.facet(end+1)=createVerFacet([0 0],[roomLength 0],0,height,'external_wall'); 
building.facet(end+1)=createHorFacet([0 roomWidth roomWidth 0],[0 0 roomLength roomLength],0,'floor');
for i=0:3
    building.facet(end+1)=createVerFacet([workingSpaceStartingX roomWidth],[i*workingSpaceLength/3 i*workingSpaceLength/3],0,workingSpaceHeight,'wood');
end
building.facet(end+1)=createHorFacet([workingSpaceStartingX roomWidth roomWidth workingSpaceStartingX],[0 0 workingSpaceLength+workingSpaceLenghtExtra workingSpaceLength+workingSpaceLenghtExtra],workingSpaceHeight,'wood');
building.facet(end+1)=createVerFacet([benchStartingX benchStartingX],[benchStartingY benchStartingY+benchLength],0,benchHeight,'bench'); 
building.facet(end+1)=createVerFacet([benchStartingX+benchWidth benchStartingX+benchWidth],[benchStartingY benchStartingY+benchLength],0,benchHeight,'bench'); 
building.facet(end+1)=createVerFacet([benchStartingX benchStartingX+benchWidth],[benchStartingY benchStartingY],0,benchHeight,'bench'); 
building.facet(end+1)=createVerFacet([benchStartingX benchStartingX+benchWidth],[benchStartingY+benchLength benchStartingY+benchLength],0,benchHeight,'bench'); 
building.facet(end+1)=createHorFacet([benchStartingX benchStartingX+benchWidth benchStartingX+benchWidth benchStartingX],[benchStartingY benchStartingY benchStartingY+benchLength benchStartingY+benchLength],benchHeight,'bench');
building.facet(end+1)=createVerFacet([doorStartingX doorStartingX+doorWidth],[0 0],0,doorHeight,'bench'); 
building.facet(end+1)=createVerFacet([doorStartingX doorStartingX+doorWidth],[roomLength roomLength],0,doorHeight,'bench');
for i=1:numberOfSelves
    building.facet(end+1)=createHorFacet([0 shelfWidth shelfWidth 0],[shelfStartingY shelfStartingY shelfStartingY+shelfLenght shelfStartingY+shelfLenght],i*shelfHeight/numberOfSelves,'wood');
end

figure
plot_environment(building); view(3)
rotate3d on; hold on; axis equal

%Define the location and orientation of the sensors
sens(1)=createSensor(45,15,0,0.46,0.33,2.81,1,'sens1');
sens(2)=createSensor(0,-35,0,0.34,4.32,1.23,1,'sens2');
sens(3)=createSensor(-45,15,0,0.53,8.5,2.39,1,'sens3');
sens(4)=createSensor(-90,0,0,4.06,8.5,1.995,1,'sens4');
sens(5)=createSensor(90,15,0,3.96,0.33,2.84,1,'sens5');

%Interpolate points
pt = interparc(numberOfElecmentsToInterpolate,x,y,z)
xData=pt(:,1);
yData=pt(:,2);
zData=pt(:,3);

numberOfscatteredPoints=randi(maxNumberofScatteredPoints);
scatterX=normrnd(xData(1),sigma,[1 numberOfscatteredPoints]);
scatterY=normrnd(yData(1),sigma,[1 numberOfscatteredPoints]);
scatterZ=normrnd(zData(1),sigma,[1 numberOfscatteredPoints]);

scatterNewMeasurements=scatter3([],[],[],'k','filled','HandleVisibility','off')
estimatedPlot=plot3(1,1,1,'-g','LineWidth',2);
groundTruth=plot3(xData,yData,zData,':r','LineWidth',2)
legend('Estimation', 'Ground Truth')

for i=1:length(xData)
    numberOfscatteredPoints=randi(maxNumberofScatteredPoints);
    scatterX=normrnd(xData(i),sigma,[1 numberOfscatteredPoints]);
    scatterY=normrnd(yData(i),sigma,[1 numberOfscatteredPoints]);
    scatterZ=normrnd(zData(i),sigma,[1 numberOfscatteredPoints]);
    for iSens=1:length(sens)
        tempXYZ(iSens,:)=rotateToSensorFrame(xData(i),yData(i),zData(i),sens(iSens).yaw,sens(iSens).pitch,sens(iSens).roll,sens(iSens).x, sens(iSens).y, sens(iSens).z)
        [AZ, EL, R]=cart2sph(tempXYZ(iSens,1),tempXYZ(iSens,2),tempXYZ(iSens,3));
        polarMeasAZ_EL_R(iSens,:)=[-AZ*180/pi EL*180/pi R];

        %Interpollate the errors based on the loaded precision analysis
        %results calculated using the precisionIWR1843XYZ.m file
        azError=interp3(dd,elev,azim,azErr,R,abs(EL*180/pi),abs(AZ*180/pi));
        elError=interp3(dd,elev,azim,elErr,R,abs(EL*180/pi),abs(AZ*180/pi));
        dError=interp3(dd,elev,azim,rangeErr,R,abs(EL*180/pi),abs(AZ*180/pi));
        AZnew=polarMeasAZ_EL_R(iSens,1)+unifrnd(-azError,azError,size(AZ));
        ELnew=polarMeasAZ_EL_R(iSens,2)+unifrnd(-elError,elError,size(EL));
        Rnew=polarMeasAZ_EL_R(iSens,3)+unifrnd(-dError,dError,size(R));
        [XnewM, YnewM, ZnewM]=sph2cart(-AZnew*pi/180,ELnew*pi/180,Rnew);
        room_pts=rotateToRoomFrame(XnewM,YnewM,ZnewM,sens(iSens).yaw,sens(iSens).pitch,sens(iSens).roll,sens(iSens).x, sens(iSens).y, sens(iSens).z);
        newMeasurementXYZ(iSens,:)=room_pts';
    end

    set(scatterNewMeasurements,'XData',newMeasurementXYZ(:,1),'YData',newMeasurementXYZ(:,2),'ZData', newMeasurementXYZ(:,3))
    estimatedX(i)=nanmean(newMeasurementXYZ(:,1));
    estimatedY(i)=nanmean(newMeasurementXYZ(:,2));
    estimatedZ(i)=nanmean(newMeasurementXYZ(:,3));
    absAZ=abs(AZnew);
    absEL=abs(ELnew);
    absR=abs(Rnew);
    Dx(i)=xData(i)-estimatedX(i);
    Dy(i)=yData(i)-estimatedY(i);
    Dz(i)=zData(i)-estimatedZ(i);
    Dxyz(i)=norm([Dx(i) Dy(i) Dz(i)]);
    set(estimatedPlot,'XData',estimatedX,'YData',estimatedY,'ZData',estimatedZ)
    pause(0.1)
end

%NEEDED Functions
function room_pts=rotateToRoomFrame(X,Y,Z,yaw,pitch,roll,anchorX, anchorY, anchorZ)
    pts=[X; Y; Z];
    anchor=[anchorX; anchorY; anchorZ];
    rot_z = [ cosd(yaw), -sind(yaw), 0; ...
              sind(yaw),  cosd(yaw), 0; ...
              0, 0, 1];
    rot_y = [cosd(pitch), 0,   sind(pitch); ...
                         0, 1,               0; ...
            -sind(pitch), 0,  cosd(pitch)];
    rot_x = [1, 0, 0; ...
              0, cosd(roll), -sind(roll); ...
              0, sind(roll),  cosd(roll)];
    rotMatrix=rot_z * rot_y * rot_x;
    room_pts = rotMatrix * pts+repmat(anchor,[1 size(pts,2)]);
end

function sensor_pts=rotateToSensorFrame(X,Y,Z,yaw,pitch,roll,anchorX, anchorY, anchorZ)
    pts=[X; Y; Z];
    anchor=[anchorX; anchorY; anchorZ];
    rot_z = [ cosd(yaw), -sind(yaw), 0; ...
              sind(yaw),  cosd(yaw), 0; ...
              0, 0, 1];
    rot_y = [cosd(pitch), 0,   sind(pitch); ...
                         0, 1,               0; ...
            -sind(pitch), 0,  cosd(pitch)];
    rot_x = [1, 0, 0; ...
              0, cosd(roll), -sind(roll); ...
              0, sind(roll),  cosd(roll)];
    rotMatrix=rot_z * rot_y * rot_x;
    sensor_pts = rotMatrix\(pts-repmat(anchor,[1 size(pts,2)]));
end

function facet=createVerFacet(X,Y,ground,ceiling,type)
    facet.coordinates=[X(1) Y(1) ground; X(2) Y(2) ground;X(2) Y(2) ceiling;X(1) Y(1) ceiling];
    facet.type=type;
    facet.child=[];
end

function facet=createHorFacet(X,Y,Elevation,type)
    for i=1:length(X)
        facet.coordinates(i,:)=[X(i) Y(i) Elevation];
    end
    facet.type=type;
    facet.child=[];
end

%Function to plot the environment
function plottedEnv=plot_environment( building)
plottedEnv=[];
alph=0.2;
%Plot the Building
for i=1:length(building.facet)
  switch building.facet(i).type
        case 'external_wall'  
            building.facet(i).coordinates=[building.facet(i).coordinates;...
                    building.facet(i).coordinates(1,:)];
            plottedEnv(i)=line( building.facet(i).coordinates(:,1),building.facet(i).coordinates(:,2),...
                building.facet(i).coordinates(:,3),'Linewidth',2,'Color','k','HandleVisibility','off');
            patch( building.facet(i).coordinates(:,1),building.facet(i).coordinates(:,2),building.facet(i).coordinates(:,3),[0.3 0.9 0.8],'FaceAlpha',alph,'HandleVisibility','off');
        case 'internal_wall'
            building.facet(i).coordinates=[building.facet(i).coordinates;...
                    building.facet(i).coordinates(1,:)];
            plottedEnv(i)=line( building.facet(i).coordinates(:,1),building.facet(i).coordinates(:,2),...
                building.facet(i).coordinates(:,3),'Linewidth',1,'Color',[0.88 0.75 0.46],'HandleVisibility','off');
            patch( building.facet(i).coordinates(:,1),building.facet(i).coordinates(:,2),building.facet(i).coordinates(:,3),[0.88 0.75 0.46],'FaceAlpha',alph,'HandleVisibility','off');
                    case 'floor'
            building.facet(i).coordinates=[building.facet(i).coordinates;...
                    building.facet(i).coordinates(1,:)];
            % plottedEnv(i)=line( building.facet(i).coordinates(:,1),building.facet(i).coordinates(:,2),...
            %     building.facet(i).coordinates(:,3),'Linewidth',2,'Color','b');
            patch( building.facet(i).coordinates(:,1),building.facet(i).coordinates(:,2),building.facet(i).coordinates(:,3),[0.3 0.9 0.8],'FaceAlpha',alph,'HandleVisibility','off');
       case 'wood'
%            patch(building.facet(i).coordinates(:,1),building.facet(i).coordinates(:,2),building.facet(i).coordinates(:,3),[0.3 0.9 0.8]);
building.facet(i).coordinates=[building.facet(i).coordinates;...
                    building.facet(i).coordinates(1,:)];
            plottedEnv(i)=line( building.facet(i).coordinates(:,1),building.facet(i).coordinates(:,2),...
                building.facet(i).coordinates(:,3),'Linewidth',2,'Color',[0.8 0.4 0.3],'HandleVisibility','off');
            patch( building.facet(i).coordinates(:,1),building.facet(i).coordinates(:,2),building.facet(i).coordinates(:,3),[0.8 0.4 0.3],'FaceAlpha',alph,'HandleVisibility','off');
        
      case 'bench'
%            patch(building.facet(i).coordinates(:,1),building.facet(i).coordinates(:,2),building.facet(i).coordinates(:,3),[0.3 0.9 0.8]);
building.facet(i).coordinates=[building.facet(i).coordinates;...
                    building.facet(i).coordinates(1,:)];
            plottedEnv(i)=line( building.facet(i).coordinates(:,1),building.facet(i).coordinates(:,2),...
                building.facet(i).coordinates(:,3),'Linewidth',2,'Color',[0.93 0.88 0.73],'HandleVisibility','off');
            patch( building.facet(i).coordinates(:,1),building.facet(i).coordinates(:,2),building.facet(i).coordinates(:,3),[0.93 0.88 0.73],'FaceAlpha',alph,'HandleVisibility','off');
      otherwise
    end

  if (~isempty(building.facet(i).child))
     for (k=1:1:length(building.facet(i).child))
         switch building.facet(i).child(k).type
             
             case 'window'
                 patch( building.facet(i).child(k).coordinates(:,1),building.facet(i).child(k).coordinates(:,2),building.facet(i).child(k).coordinates(:,3),[0.3 0.9 0.8],'HandleVisibility','off');
             case 'wooden_door'
                 patch( building.facet(i).child(k).coordinates(:,1),building.facet(i).child(k).coordinates(:,2),building.facet(i).child(k).coordinates(:,3),[0.8 0.4 0.3],'HandleVisibility','off');
             case 'metal_door'
                 patch( building.facet(i).child(k).coordinates(:,1),building.facet(i).child(k).coordinates(:,2),building.facet(i).child(k).coordinates(:,3),[0.43 0.38 0.38],'FaceAlpha',alph,'HandleVisibility','off');
             otherwise
         end
      end
  end
end

end

function sensor=createSensor(yaw,pitch,roll,x,y,z,plotSensor,sensorName)
sensor.height=0.3;sensor.width=0.2;sensor.depth=0.05;
sensor.yaw=yaw;sensor.pitch=pitch;sensor.roll=roll;
sensor.x=x;sensor.y=y;sensor.z=z;
sensor.name=sensorName;
location=[x y z]';
if plotSensor
    % Set up an array of points for a cube
    pts = [1 1 1 1 -1 -1 -1 -1 ;
        1 1 -1 -1 1 1 -1 -1 ;
        1 -1 1 -1 1 -1 1 -1 ];
    pts=pts.*[sensor.depth;sensor.width;sensor.height];
    rot_z = [ cosd(yaw), -sind(yaw), 0; ...
          sind(yaw),  cosd(yaw), 0; ...
          0, 0, 1];
    rot_y = [cosd(pitch), 0,   sind(pitch); ...
                         0, 1,               0; ...
            -sind(pitch), 0,  cosd(pitch)];
    rot_x = [1, 0, 0; ...
              0, cosd(roll), -sind(roll); ...
              0, sind(roll),  cosd(roll)];
    % Rotate the points
    rot_pts = rot_z * rot_y * rot_x * pts+repmat(location,[1 size(pts,2)]);
    % Plot the axis marker
    axisSize=0.5;
    axesPoints=[0 axisSize  0 0 0 0;
        0 0 0 axisSize 0 0;
        0 0 0 0 0 axisSize];
    rot_axesPoints=rot_z * rot_y * rot_x * axesPoints+repmat(location,[1 6]);
    plot3([rot_axesPoints(1,1) rot_axesPoints(1,2)],[rot_axesPoints(2,1) rot_axesPoints(2,2)], [rot_axesPoints(3,1) rot_axesPoints(3,2)],'r','linewidth',1,'HandleVisibility','off');
    hold on;
    plot3([rot_axesPoints(1,3) rot_axesPoints(1,4)],[rot_axesPoints(2,3) rot_axesPoints(2,4)], [rot_axesPoints(3,3) rot_axesPoints(3,4)],'g','linewidth',1,'HandleVisibility','off');
    plot3([rot_axesPoints(1,5) rot_axesPoints(1,6)],[rot_axesPoints(2,5) rot_axesPoints(2,6)], [rot_axesPoints(3,5) rot_axesPoints(3,6)],'b','linewidth',1,'HandleVisibility','off');
    plot3(rot_pts(1,:), rot_pts(2,:), rot_pts(3,:),'.k','MarkerSize',5,'HandleVisibility','off');

    % Plot the edges (original then rotated)
    segment_order = [1,2;3,4;5,6;7,8;1,3;2,4;5,7;6,8;1,5;2,6;3,7;4,8];
    
    for i = 1:size(segment_order, 1)
       % plot3(pts(1,segment_order(i,:)), pts(2,segment_order(i,:)), pts(3,segment_order(i,:)), ':b');
       plot3(rot_pts(1,segment_order(i,:)), rot_pts(2,segment_order(i,:)), rot_pts(3,segment_order(i,:)), '-k','HandleVisibility','off');
    end
    text(rot_axesPoints(1,2),rot_axesPoints(2,2),rot_axesPoints(3,2),'X','Color','red')
    text(rot_axesPoints(1,4),rot_axesPoints(2,4),rot_axesPoints(3,4),'Y','Color','green')
    text(rot_axesPoints(1,6),rot_axesPoints(2,6),rot_axesPoints(3,6),'Z','Color','blue')
    text(x,y,z+0.5,sensorName,"FontSize",12,"FontWeight","bold")
end
end



